"""
This sample demonstrates a simple skill built with the Amazon Alexa Skills Kit.
The Intent Schema, Custom Slots, and Sample Utterances for this skill, as well
as testing instructions are located at http://amzn.to/1LzFrj6

For additional samples, visit the Alexa Skills Kit Getting Started guide at
http://amzn.to/1LGWsLG
"""

from __future__ import print_function
import urllib2
import datetime
import json
import pytz
import dateutil.parser

# ----------- NOTES on API calls -----------
# Filter routes for ID ("Red", "Green-E", etc): 
#           routes/?filter%5Bid%5D={id}
# Prediction by stop ID and line ("place-dwnxg" and "Orange"):
#           predictions/?filter%5Bstop%5D={stop}&filter%5Broute%5D={line}
# Find all stops for a line:
#           stops/?fields%5Bstop%5D=name&filter%5Broute%5D={line}


# Basic request necessities
url = "https://api-v3.mbta.com"  # base url
predictions_url = url + "/predictions"  # url for predictions
routes_url = url + "/routes"
stops_url = url + "/stops"
api_key = "22fe3c7f0b354f608344baf15601c305"  # API key for MBTA API v3
default_sort = "arrival-time"  # sort by closest arrival



# --------------- Helpers that build all of the responses ----------------------

def build_speechlet_response(title, output, reprompt_text, should_end_session):
    return {
        'outputSpeech': {
            'type': 'PlainText',
            'text': output
        },
        'card': {
            'type': 'Simple',
            'title': "SessionSpeechlet - " + title,
            'content': "SessionSpeechlet - " + output
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'shouldEndSession': should_end_session
    }


def build_response(session_attributes, speechlet_response):
    return {
        'version': '1.0',
        'sessionAttributes': session_attributes,
        'response': speechlet_response
    }


# --------------- Functions that control the skill's behavior ------------------

def get_welcome_response():
    """ If we wanted to initialize the session to have some attributes we could
    add those here
    """

    session_attributes = {}
    card_title = "Welcome"
    speech_output = "What's up Casey? You big dumb idiot ha ha ha"
    # If the user either does not reply to the welcome message or says something
    # that is not understood, they will be prompted again with this text.
    reprompt_text = "Please tell me your favorite color by saying, " \
                    "my favorite color is red."
    should_end_session = True
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def handle_session_end_request():
    card_title = "Session Ended"
    speech_output = "Thank you for using Boston Train Party. " \
                    "Have a nice day! "
    # Setting this to true ends the session and exits the skill.
    should_end_session = True
    return build_response({}, build_speechlet_response(
        card_title, speech_output, None, should_end_session))

def build_route_url(route):
    global routes_url
    url = routes_url + "/" + route
    return url

def build_stop_url(route):
    global stops_url
    url = stops_url + "/?fields%5Bstop%5D=name&filter%5Broute%5D=" + route
    return url

def build_prediction_url(stop, route, direction):
    global predictions_url
    url = predictions_url + "/?fields%5Bprediction%5D=arrival_time&" + \
        "filter%5Bstop%5D=" + stop + "&filter%5Broute%5D=" + route
    url += "&filter%5Bdirection_id%5D=" + str(direction) + "&page%5Blimit%5D=2"
    print(url)
    return url

def find_train_time(intent, session):
    """ 
    """
    card_title = intent['name']
    should_end_session = True

    if ('direction' in intent['slots'] and 
            'route' in intent['slots'] and  'stop' in intent['slots']):
        direc = intent['slots']['direction']['resolutions']['resolutionsPerAuthority'][0]['values'][0]['value']['name'] 
        route = intent['slots']['route']['resolutions']['resolutionsPerAuthority'][0]['values'][0]['value']['name']
        stop = intent['slots']['stop']['resolutions']['resolutionsPerAuthority'][0]['values'][0]['value']['name']

        # Find direction info
        dir_response = urllib2.urlopen(build_route_url(route))
        dir_response_data = json.loads(dir_response.read())['data']
        route_dirs = dir_response_data['attributes']['direction_names']
        dir_index = -1
        for i, d in enumerate(route_dirs):
            if d == direc:
                dir_index = i

        if dir_index > -1:
            # Find the stop ID
            stop_response = urllib2.urlopen(build_stop_url(route))
            stop_response_data = json.loads(stop_response.read())['data']
            stop_id = ""
            for stop_data in stop_response_data:
                if stop == stop_data['attributes']['name']:
                    stop_id = stop_data['id']
                    break

            prediction_response = urllib2.urlopen(build_prediction_url(stop_id, route, dir_index))
            prediction_response_data = json.loads(prediction_response.read())['data']
            arrive_time_str = prediction_response_data[0]['attributes']['arrival_time']
            #arrival_time = datetime.datetime.strptime(arrive_time_str[:len(arrive_time_str) - 6], "%Y-%m-%dT%H:%M:%S")
            arrival_time = dateutil.parser.parse(arrive_time_str)
            arrival_time = arrival_time.replace(tzinfo=pytz.utc) - arrival_time.utcoffset()
            print(arrival_time)
            print(datetime.datetime.utcnow().replace(tzinfo=pytz.utc))
            delta = arrival_time - datetime.datetime.utcnow().replace(tzinfo=pytz.utc)
            delta_str = ""
            if delta.days < 0:
                delta_str = "boarding"
            elif delta.seconds <= 60:
                delta_str = str(delta.seconds) + " seconds away"
            else:
                delta_str = str(int(delta.seconds / 60))
                if delta_str == "1":
                    delta_str += " minute away"
                else:
                    delta_str += " minutes away"
            speech_output = "The next " + direc + " " + route + " line at " + stop + " is " + delta_str + arrive_time_str
            reprompt_text = "You can ask me your favorite color by saying, " \
                            "what's my favorite color?"
        else:
            speech_output = "Please try again. The directions for the " + \
                            route + " line are " + route_dirs[0] + " and " + route_dirs[1]
            reprompt_text = ""
    else:
        speech_output = "I'm not sure what your favorite color is. " \
                        "Please try again."
        reprompt_text = "I'm not sure what your favorite color is. " \
                        "You can tell me your favorite color by saying, " \
                        "my favorite color is red."
    print(speech_output)
    return build_response({}, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


# --------------- Events ------------------

def on_session_started(session_started_request, session):
    """ Called when the session starts """

    print("on_session_started requestId=" + session_started_request['requestId']
          + ", sessionId=" + session['sessionId'])


def on_launch(launch_request, session):
    """ Called when the user launches the skill without specifying what they
    want
    """

    print("on_launch requestId=" + launch_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # Dispatch to your skill's launch
    return get_welcome_response()


def on_intent(intent_request, session):
    """ Called when the user specifies an intent for this skill """

    print("on_intent requestId=" + intent_request['requestId'] +
          ", sessionId=" + session['sessionId'])

    intent = intent_request['intent']
    intent_name = intent_request['intent']['name']

    # Dispatch to your skill's intent handlers
    if intent_name == "TrainTimeAway":
        return find_train_time(intent, session)
    elif intent_name == "AMAZON.HelpIntent":
        return get_welcome_response()
    elif intent_name == "AMAZON.CancelIntent" or intent_name == "AMAZON.StopIntent":
        return handle_session_end_request()
    else:
        raise ValueError("Invalid intent")


def on_session_ended(session_ended_request, session):
    """ Called when the user ends the session.

    Is not called when the skill returns should_end_session=true
    """
    print("on_session_ended requestId=" + session_ended_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # add cleanup logic here


# --------------- Main handler ------------------

def lambda_handler(event, context):
    """ Route the incoming request based on type (LaunchRequest, IntentRequest,
    etc.) The JSON body of the request is provided in the event parameter.
    """
    print("event.session.application.applicationId=" +
          event['session']['application']['applicationId'])

    """
    Uncomment this if statement and populate with your skill's application ID to
    prevent someone else from configuring a skill that sends requests to this
    function.
    """
    # if (event['session']['application']['applicationId'] !=
    #         "amzn1.echo-sdk-ams.app.[unique-value-here]"):
    #     raise ValueError("Invalid Application ID")

    if event['session']['new']:
        on_session_started({'requestId': event['request']['requestId']},
                           event['session'])

    if event['request']['type'] == "LaunchRequest":
        return on_launch(event['request'], event['session'])
    elif event['request']['type'] == "IntentRequest":
        return on_intent(event['request'], event['session'])
    elif event['request']['type'] == "SessionEndedRequest":
        return on_session_ended(event['request'], event['session'])



testJson = {
    "version": "1.0",
    "session": {
        "new": True,
        "sessionId": "amzn1.echo-api.session.7eba4497-2a23-4792-bd89-f3b1fb7a59e6",
        "application": {
            "applicationId": "amzn1.ask.skill.489c1bc5-928a-436e-93d1-6edf0d25d6e3"
        },
        "user": {
            "userId": "amzn1.ask.account.AGWUUA2FK26XASDV6RLWXZJNC4BQ2CCXKMFFIKAZRKDNX23E3WIEZIOX2I52RMYCJKBA5BCAGJHKCMUFJ42R2YHDPLJ5IOW7WRYEN7RZN6GSJ6KDA4FRTQFANSXFWDXSM3I3UMHNA2LYEWYTRNDO6BQGLTOXM3ZJQRVHQKEGK4FONBFGANV5S7D6SEIRPRZ46FFULNWYZMMWCPI"
        }
    },
    "context": {
        "AudioPlayer": {
            "playerActivity": "IDLE"
        },
        "Display": {
            "token": ""
        },
        "System": {
            "application": {
                "applicationId": "amzn1.ask.skill.489c1bc5-928a-436e-93d1-6edf0d25d6e3"
            },
            "user": {
                "userId": "amzn1.ask.account.AGWUUA2FK26XASDV6RLWXZJNC4BQ2CCXKMFFIKAZRKDNX23E3WIEZIOX2I52RMYCJKBA5BCAGJHKCMUFJ42R2YHDPLJ5IOW7WRYEN7RZN6GSJ6KDA4FRTQFANSXFWDXSM3I3UMHNA2LYEWYTRNDO6BQGLTOXM3ZJQRVHQKEGK4FONBFGANV5S7D6SEIRPRZ46FFULNWYZMMWCPI"
            },
            "device": {
                "deviceId": "amzn1.ask.device.AHSICQAKKLVYXNXN66H3RTQPUAHGJPUQXG4VB2DCR6GM2BQVJFBEY2XX7TFNH5QYJSRBS52F3A2WHXQ7YZQF7ZZHSE7IOIBVMLGXX7WPYUU6M4YBT7MGIKOJWDVFN5OY4UAEOHGYDMGHR4SIPCUBBU3LPY6A",
                "supportedInterfaces": {
                    "AudioPlayer": {},
                    "Display": {
                        "templateVersion": "1.0",
                        "markupVersion": "1.0"
                    }
                }
            },
            "apiEndpoint": "https://api.amazonalexa.com",
            "apiAccessToken": "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjEifQ.eyJhdWQiOiJodHRwczovL2FwaS5hbWF6b25hbGV4YS5jb20iLCJpc3MiOiJBbGV4YVNraWxsS2l0Iiwic3ViIjoiYW16bjEuYXNrLnNraWxsLjQ4OWMxYmM1LTkyOGEtNDM2ZS05M2QxLTZlZGYwZDI1ZDZlMyIsImV4cCI6MTUyNjU5NjE0MCwiaWF0IjoxNTI2NTkyNTQwLCJuYmYiOjE1MjY1OTI1NDAsInByaXZhdGVDbGFpbXMiOnsiY29uc2VudFRva2VuIjpudWxsLCJkZXZpY2VJZCI6ImFtem4xLmFzay5kZXZpY2UuQUhTSUNRQUtLTFZZWE5YTjY2SDNSVFFQVUFIR0pQVVFYRzRWQjJEQ1I2R00yQlFWSkZCRVkyWFg3VEZOSDVRWUpTUkJTNTJGM0EyV0hYUTdZWlFGN1paSFNFN0lPSUJWTUxHWFg3V1BZVVU2TTRZQlQ3TUdJS09KV0RWRk41T1k0VUFFT0hHWURNR0hSNFNJUENVQkJVM0xQWTZBIiwidXNlcklkIjoiYW16bjEuYXNrLmFjY291bnQuQUdXVVVBMkZLMjZYQVNEVjZSTFdYWkpOQzRCUTJDQ1hLTUZGSUtBWlJLRE5YMjNFM1dJRVpJT1gySTUyUk1ZQ0pLQkE1QkNBR0pIS0NNVUZKNDJSMllIRFBMSjVJT1c3V1JZRU43UlpONkdTSjZLREE0RlJUUUZBTlNYRldEWFNNM0kzVU1ITkEyTFlFV1lUUk5ETzZCUUdMVE9YTTNaSlFSVkhRS0VHSzRGT05CRkdBTlY1UzdENlNFSVJQUlo0NkZGVUxOV1laTU1XQ1BJIn19.comA6LDu7IEjS2PAmdxttKtBnbkayZrM-5EvJkjj3RZk9wqPCDEAP8nSsBeIXa9dhNy0VdtLYPnQZnm2TbgqHEskh66ePl6djyfq28ytK9buHTezGylBUrEMFONHIRe7wwAbhKGlPpTqtzb8ANoN6rh7bWorTd8z3Hun4DsbTAhTUIwqGFZDbQ1VnslLGvVS99BVcmzkPCaZxswTrEnSyRttoSvmHxwhFfejyz67WjcbfOjmnF3tUrpz2ifkGYSZM5aX02I6PskZupZwDAFSLhIq2DFNOCeQCgw1M4GRfTKVHyQcUMM-OatMFhZh1N0HmPS6IQ2UL1O_MH1uVZI5Ow"
        }
    },
    "request": {
        "type": "IntentRequest",
        "requestId": "amzn1.echo-api.request.b1c36332-c30c-40ec-a364-1c8bce0673a0",
        "timestamp": "2018-05-17T21:29:00Z",
        "locale": "en-US",
        "intent": {
            "name": "TrainTimeAway",
            "confirmationStatus": "NONE",
            "slots": {
                "route": {
                    "name": "route",
                    "value": "green e",
                    "resolutions": {
                        "resolutionsPerAuthority": [
                            {
                                "authority": "amzn1.er-authority.echo-sdk.amzn1.ask.skill.489c1bc5-928a-436e-93d1-6edf0d25d6e3.mbta_line",
                                "status": {
                                    "code": "ER_SUCCESS_MATCH"
                                },
                                "values": [
                                    {
                                        "value": {
                                            "name": "Green-E",
                                            "id": "37ed9d45dc23b80a94cdd17e51096c58"
                                        }
                                    }
                                ]
                            }
                        ]
                    },
                    "confirmationStatus": "NONE"
                },
                "stop": {
                    "name": "stop",
                    "value": "Brigham circle",
                    "resolutions": {
                        "resolutionsPerAuthority": [
                            {
                                "authority": "amzn1.er-authority.echo-sdk.amzn1.ask.skill.489c1bc5-928a-436e-93d1-6edf0d25d6e3.mbta_station",
                                "status": {
                                    "code": "ER_SUCCESS_MATCH"
                                },
                                "values": [
                                    {
                                        "value": {
                                            "name": "Brigham Circle",
                                            "id": "f7b0ed5d4349618fea747b562276a105"
                                        }
                                    }
                                ]
                            }
                        ]
                    },
                    "confirmationStatus": "NONE"
                },
                "direction": {
                    "name": "direction",
                    "value": "eastbound",
                    "resolutions": {
                        "resolutionsPerAuthority": [
                            {
                                "authority": "amzn1.er-authority.echo-sdk.amzn1.ask.skill.489c1bc5-928a-436e-93d1-6edf0d25d6e3.mbta_direction",
                                "status": {
                                    "code": "ER_SUCCESS_MATCH"
                                },
                                "values": [
                                    {
                                        "value": {
                                            "name": "Westbound",
                                            "id": "24ce5da5d60de4062a4255fd7f47b854"
                                        }
                                    }
                                ]
                            }
                        ]
                    },
                    "confirmationStatus": "NONE"
                }
            }
        },
        "dialogState": "STARTED"
    }
}

lambda_handler(testJson, "")
